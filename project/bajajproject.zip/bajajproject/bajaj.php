<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="refresh" content="">
	<link rel="icon"  href="ic.png">
	<title>ROYAL BAJAJ</title>
    <link rel="stylesheet" type="text/css" href="home.css">
    <link rel="stylesheet" type="text/css" href="login2.css">
    </head>
<body>
	<ul>
  <img src="logo\logo.png" height="9%" width="10%">
        
        <li><a><button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">LOGIN</button></a></li>
  <li><a><img src="logo\phn.png"width="40" height="20" > Customer Care:+91 9188082932 | </a></li>

<li><a><img src="logo\msg.png" width="30" height="20">  Adimalyroyal@gmail.com | </a></li>

  <li><a href="brands.php" ><img src="logo\bike.png"width="50" height="20"> brands | <a></li>
</ul>
<img src="img\h.png" width="100%" height="90%">
      
</body>
</html>
    
<?php include('login.php')?>
